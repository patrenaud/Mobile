package ca.patrickrenaudbart.missilecommand;

public interface Constants {



    long UPDATE_TIME_MS = 10L;
    long UPDATE_TIME_NS = UPDATE_TIME_MS * 1000000L;

}
