package ca.patrickrenaudbart.missilecommand;

import android.graphics.Canvas;

public interface IDrawable {

    void Draw(Canvas canvas);

}