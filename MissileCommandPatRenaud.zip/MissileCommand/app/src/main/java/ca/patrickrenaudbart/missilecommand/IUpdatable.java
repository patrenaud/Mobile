package ca.patrickrenaudbart.missilecommand;

public interface IUpdatable {

    void Update();

}
