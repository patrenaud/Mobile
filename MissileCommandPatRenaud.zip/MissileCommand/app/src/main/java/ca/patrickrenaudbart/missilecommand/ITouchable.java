package ca.patrickrenaudbart.missilecommand;

import android.view.MotionEvent;

public interface ITouchable {

    boolean OnTouch(MotionEvent motionEvent);

}
